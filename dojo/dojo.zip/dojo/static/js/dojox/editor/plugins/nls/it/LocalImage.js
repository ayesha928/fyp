//>>built
define("dojox/editor/plugins/nls/it/LocalImage",({insertImageTitle:"Inserisci immagine",url:"Immagine",browse:"Sfoglia...",text:"Descrizione",set:"Inserisci",invalidMessage:"Tipo file immagine non valido",prePopuTextUrl:"Immettere un URL immagine",prePopuTextBrowse:" o selezionare un file locale."}));
