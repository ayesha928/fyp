define(
"dojox/editor/plugins/nls/el/AutoSave", ({
	"saveLabel": "Αποθήκευση",
	"saveSettingLabelOn": "Ορισμός διαστήματος αυτόματης αποθήκευσης...",
	"saveSettingLabelOff": "Απενεργοποίηση αυτόματης αποθήκευσης",
	"saveSettingdialogTitle": "Αυτόματη αποθήκευση",
	"saveSettingdialogDescription": "Ορισμός διαστήματος αυτόματης αποθήκευσης",
	"saveSettingdialogParamName": "Διάστημα αυτόματης αποθήκευσης",
	"saveSettingdialogParamLabel": "λεπτά",
	"saveSettingdialogButtonOk": "Ορισμός διαστήματος",
	"saveSettingdialogButtonCancel": "Ακύρωση",
	"saveMessageSuccess": "Αποθηκεύτηκε στις ${0}",
	"saveMessageFail": "Απέτυχε η αποθήκευση στις ${0}"
})
);
