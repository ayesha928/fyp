define(
"dojox/editor/plugins/nls/ja/Save", ({
	"save": "保存"
})
);
