define(
"dojox/editor/plugins/nls/pl/InsertEntity", ({
	insertEntity: "Wstaw symbol"
})
);
