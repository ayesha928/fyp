define(
"dojox/editor/plugins/nls/pt-pt/Save", ({
	"save": "Guardar"
})
);
