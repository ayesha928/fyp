//>>built
define("dojox/editor/plugins/nls/pt-pt/SafePaste",({"instructions":"Colar directamente não está activado. Cole o conteúdo nesta caixa de diálogo utilizando o teclado do browser standard ou os controlos do menu Colar. Quando estiver satisfeito com o conteúdo a inserir, prima o botão Colar. Para cancelar a inserção de texto, prima o botão Cancelar."}));
