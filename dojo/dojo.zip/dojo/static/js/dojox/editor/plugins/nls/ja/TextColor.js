//>>built
define("dojox/editor/plugins/nls/ja/TextColor",({"setButtonText":"設定","cancelButtonText":"キャンセル"}));
