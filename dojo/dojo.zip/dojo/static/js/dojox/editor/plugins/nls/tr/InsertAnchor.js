//>>built
define("dojox/editor/plugins/nls/tr/InsertAnchor",({insertAnchor:"Tutturucu Ekle",title:"Tutturucu Özellikleri",anchor:"Ad:",text:"Açıklama:",set:"Ayarla",cancel:"İptal"}));
