define(
"dojox/editor/plugins/nls/it/TextColor", ({
	"setButtonText": "Imposta",
	"cancelButtonText": "Annulla"
})
);
