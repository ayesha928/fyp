define(
"dojox/editor/plugins/nls/pl/ShowBlockNodes", ({
	"showBlockNodes": "Pokaż elementy bloków HTML"
})
);
