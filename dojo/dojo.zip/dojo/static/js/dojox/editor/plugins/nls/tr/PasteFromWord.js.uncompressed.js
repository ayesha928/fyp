define(
"dojox/editor/plugins/nls/tr/PasteFromWord", ({
	"pasteFromWord": "Word'den Kopyala",
	"instructions": "İçeriği Word'den aşağıdaki metin kutusuna yapıştırın. Eklediğiniz içerikten memnunsanız, Yapıştır düğmesini tıklatın. Metin eklemeyi durdurmak için İptal düğmesini tıklatın."
})
);
