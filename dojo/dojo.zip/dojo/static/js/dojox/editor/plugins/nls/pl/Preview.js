//>>built
define("dojox/editor/plugins/nls/pl/Preview",({"preview":"Podgląd"}));
