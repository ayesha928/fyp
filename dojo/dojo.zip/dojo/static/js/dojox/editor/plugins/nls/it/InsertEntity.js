//>>built
define("dojox/editor/plugins/nls/it/InsertEntity",({insertEntity:"Inserisci simbolo"}));
