define(
"dojox/editor/plugins/nls/pt-pt/PageBreak", ({
	"pageBreak": "Quebra de página"
})
);
