define(
"dojox/editor/plugins/nls/pl/PageBreak", ({
	"pageBreak": "Podział strony"
})
);
