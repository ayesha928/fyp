//>>built
define("dojox/editor/plugins/nls/ja/Breadcrumb",({"nodeActions":"${nodeName} アクション","selectContents":"コンテンツの選択","selectElement":"エレメントの選択","deleteElement":"エレメントの削除","deleteContents":"コンテンツの削除","moveStart":"カーソルを先頭に移動","moveEnd":"カーソルを最後尾に移動"}));
