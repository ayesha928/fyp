define(
"dojox/editor/plugins/nls/da/LocalImage", ({
	insertImageTitle: "Indsæt billede",
	url: "Billede",
	browse: "Gennemse...",
	text: "Beskrivelse",
	set: "Indsæt",
	invalidMessage: "Ugyldig type af billedfil",
	prePopuTextUrl: "Angiv en billed-URL",
	prePopuTextBrowse: " eller søg efter en lokal fil."
})
);
