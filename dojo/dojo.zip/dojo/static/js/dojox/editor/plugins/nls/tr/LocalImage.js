//>>built
define("dojox/editor/plugins/nls/tr/LocalImage",({insertImageTitle:"Resim Ekle",url:"Resim",browse:"Göz at...",text:"Açıklama",set:"Ekle",invalidMessage:"Geçersiz resim dosyası tipi",prePopuTextUrl:"Bir resim URL'si girin",prePopuTextBrowse:" ya da yerel bir dosyaya göz atın."}));
