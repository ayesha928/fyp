//>>built
define("dojox/editor/plugins/nls/da/Preview",({"preview":"Eksempel"}));
