define(
"dojox/editor/plugins/nls/da/Smiley", ({
	smiley: "Indsæt humørikon",
	emoticonSmile: "smil",
	emoticonLaughing: "ler",
	emoticonWink: "blink",
	emoticonGrin: "grin",
	emoticonCool: "sej",
	emoticonAngry: "vred",
	emoticonHalf: "halv",
	emoticonEyebrow: "øjenbryn",
	emoticonFrown: "rynker panden",
	emoticonShy: "genert",
	emoticonGoofy: "skør",
	emoticonOops: "ups",
	emoticonTongue: "tungen ud",
	emoticonIdea: "idé",
	emoticonYes: "ja",
	emoticonNo: "nej",
	emoticonAngel: "engel",
	emoticonCrying: "græder",
	emoticonHappy: "glad"
})
);
