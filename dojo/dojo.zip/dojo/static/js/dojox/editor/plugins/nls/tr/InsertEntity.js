//>>built
define("dojox/editor/plugins/nls/tr/InsertEntity",({insertEntity:"Simge Ekle"}));
