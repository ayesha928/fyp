define(
"dojox/editor/plugins/nls/pl/Save", ({
	"save": "Zapisz"
})
);
