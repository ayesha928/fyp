define(
"dojox/editor/plugins/nls/tr/Save", ({
	"save": "Kaydet"
})
);
