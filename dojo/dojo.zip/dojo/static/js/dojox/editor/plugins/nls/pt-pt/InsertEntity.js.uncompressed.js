define(
"dojox/editor/plugins/nls/pt-pt/InsertEntity", ({
	insertEntity: "Inserir símbolo"
})
);
