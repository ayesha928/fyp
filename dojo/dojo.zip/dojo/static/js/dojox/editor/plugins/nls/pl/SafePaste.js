//>>built
define("dojox/editor/plugins/nls/pl/SafePaste",({"instructions":"Wklejanie bezpośrednie jest wyłączone. Wklej treść do tego okna dialogowego za pomocą standardowych skrótów klawiszowych przeglądarki lub opcji Wklej w menu. Po uzyskaniu odpowiedniej treści do wstawienia kliknij przycisk Wklej. Aby przerwać wstawianie treści, kliknij przycisk Anuluj."}));
