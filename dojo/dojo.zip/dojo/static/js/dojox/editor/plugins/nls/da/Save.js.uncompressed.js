define(
"dojox/editor/plugins/nls/da/Save", ({
	"save": "Gem"
})
);
