define(
"dojox/editor/plugins/nls/pt/InsertAnchor", ({
	insertAnchor: "Inserir Âncora",
	title: "Propriedades de Âncora",
	anchor: "Nome:",
	text: "Descrição:",
	set: "Configurar",
	cancel: "Cancelar"
})
);
