//>>built
define("dojox/editor/plugins/nls/ja/Preview",({"preview":"プレビュー"}));
