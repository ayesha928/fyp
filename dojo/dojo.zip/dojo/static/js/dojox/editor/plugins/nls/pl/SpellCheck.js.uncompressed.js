define(
"dojox/editor/plugins/nls/pl/SpellCheck", ({
	widgetLabel: "Wsadowe sprawdzanie pisowni",
	unfound: "Nie znaleziono",
	skip: "Pomiń",
	skipAll: "Pomiń wszystko",
	toDic: "Dodaj do słownika",
	suggestions: "Propozycje",
	replace: "Zastąp",
	replaceWith: "Zastąp przez",
	replaceAll: "Zastąp wszystko",
	cancel: "Anuluj",
	msg: "Nie znaleziono błędów pisowni",
	iSkip: "Pomiń tę pozycję",
	iSkipAll: "Pomiń wszystkie pozycje podobne do tej",
	iMsg: "Brak propozycji pisowni"
})
);
