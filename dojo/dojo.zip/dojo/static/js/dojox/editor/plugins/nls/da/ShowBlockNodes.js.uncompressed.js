define(
"dojox/editor/plugins/nls/da/ShowBlockNodes", ({
	"showBlockNodes": "Vis HTML-blokelementer"
})
);
