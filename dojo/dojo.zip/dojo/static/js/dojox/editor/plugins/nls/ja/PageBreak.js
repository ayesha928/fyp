//>>built
define("dojox/editor/plugins/nls/ja/PageBreak",({"pageBreak":"改ページ"}));
