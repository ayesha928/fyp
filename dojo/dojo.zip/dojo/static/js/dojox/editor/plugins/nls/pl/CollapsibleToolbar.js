//>>built
define("dojox/editor/plugins/nls/pl/CollapsibleToolbar",({"collapse":"Zwiń pasek narzędzi edytora","expand":"Rozwiń pasek narzędzi edytora"}));
