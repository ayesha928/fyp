define(
"dojox/editor/plugins/nls/tr/Breadcrumb", ({
	"nodeActions": "${nodeName} Eylemleri",
	"selectContents": "İçindekileri seç",
	"selectElement": "Öğeyi seç",
	"deleteElement": "Öğeyi sil",
	"deleteContents": "İçindekileri sil",
	"moveStart": "İmleci başa taşı",
	"moveEnd": "İmleci sona taşı"
})
);
