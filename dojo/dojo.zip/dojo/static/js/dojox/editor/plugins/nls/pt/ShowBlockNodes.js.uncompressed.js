define(
"dojox/editor/plugins/nls/pt/ShowBlockNodes", ({
	"showBlockNodes": "Mostrar Elementos de Bloco HTML"
})
);
