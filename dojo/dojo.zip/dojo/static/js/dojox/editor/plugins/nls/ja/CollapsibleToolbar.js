//>>built
define("dojox/editor/plugins/nls/ja/CollapsibleToolbar",({"collapse":"エディター・ツールバーを省略","expand":"エディター・ツールバーを展開"}));
