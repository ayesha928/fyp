define(
"dojox/editor/plugins/nls/ja/Blockquote", ({
	"blockquote": "引用"
})
);
