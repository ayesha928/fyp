//>>built
define("dojox/editor/plugins/nls/pt-pt/PasteFromWord",({"pasteFromWord":"Colar do Word","instructions":"Cole o conteúdo do Word na caixa de texto abaixo. Após estar satisfeito com o conteúdo a inserir, prima o botão de colagem. Para cancelar a inserção de texto, prima o botão de cancelamento."}));
