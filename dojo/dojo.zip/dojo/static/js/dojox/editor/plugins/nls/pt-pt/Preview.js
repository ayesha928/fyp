//>>built
define("dojox/editor/plugins/nls/pt-pt/Preview",({"preview":"Pré-visualizar"}));
