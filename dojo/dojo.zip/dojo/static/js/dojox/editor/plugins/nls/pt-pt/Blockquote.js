//>>built
define("dojox/editor/plugins/nls/pt-pt/Blockquote",({"blockquote":"Blockquote"}));
