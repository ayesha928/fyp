define(
"dojox/editor/plugins/nls/da/SpellCheck", ({
	widgetLabel: "Bundtvis stavekontrol",
	unfound: "Ikke fundet",
	skip: "Spring over",
	skipAll: "Spring alle over",
	toDic: "Tilføj til ordbog",
	suggestions: "Forslag",
	replace: "Erstat",
	replaceWith: "Erstat med",
	replaceAll: "Erstat alle",
	cancel: "Annullér",
	msg: "Ingen stavefejl fundet",
	iSkip: "Spring dette over",
	iSkipAll: "Spring alle disse over",
	iMsg: "Ingen forslag til stavning"
})
);
