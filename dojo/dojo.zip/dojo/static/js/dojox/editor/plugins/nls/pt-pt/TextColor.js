//>>built
define("dojox/editor/plugins/nls/pt-pt/TextColor",({"setButtonText":"Definir","cancelButtonText":"Cancelar"}));
