//>>built
define("dojox/editor/plugins/nls/el/ShowBlockNodes",({"showBlockNodes":"Εμφάνιση στοιχείων ενότητας HTML"}));
