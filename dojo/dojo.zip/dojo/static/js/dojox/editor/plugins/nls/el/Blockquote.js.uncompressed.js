define(
"dojox/editor/plugins/nls/el/Blockquote", ({
	"blockquote": "Ενότητα παράθεσης"
})
);
