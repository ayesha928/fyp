define(
"dojox/editor/plugins/nls/tr/ShowBlockNodes", ({
	"showBlockNodes": "HTML Bloğu Öğelerini Göster"
})
);
