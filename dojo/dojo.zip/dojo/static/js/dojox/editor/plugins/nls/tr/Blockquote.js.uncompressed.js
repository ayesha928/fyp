define(
"dojox/editor/plugins/nls/tr/Blockquote", ({
	"blockquote": "Öbek"
})
);
