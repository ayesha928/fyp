//>>built
define("dojox/editor/plugins/nls/ja/LocalImage",({insertImageTitle:"イメージの挿入",url:"イメージ",browse:"参照...",text:"説明",set:"挿入",invalidMessage:"無効なイメージ・ファイル・タイプです",prePopuTextUrl:"イメージ URL を入力してください",prePopuTextBrowse:"またはローカル・ファイルを参照してください"}));
