define(
"dojox/editor/plugins/nls/pt/TextColor", ({
	"setButtonText": "Configurar",
	"cancelButtonText": "Cancelar"
})
);
