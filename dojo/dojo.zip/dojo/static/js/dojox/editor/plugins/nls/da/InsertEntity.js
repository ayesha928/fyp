//>>built
define("dojox/editor/plugins/nls/da/InsertEntity",({insertEntity:"Indsæt symbol"}));
