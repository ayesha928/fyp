//>>built
define("dojox/editor/plugins/nls/el/Save",({"save":"Αποθήκευση"}));
