define(
"dojox/editor/plugins/nls/tr/CollapsibleToolbar", ({
	"collapse": "Düzenleyici Araç Çubuğunu Daralt",
	"expand": "Düzenleyici Araç Çubuğunu Genişlet"
})
);
