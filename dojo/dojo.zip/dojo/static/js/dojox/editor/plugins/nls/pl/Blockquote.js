//>>built
define("dojox/editor/plugins/nls/pl/Blockquote",({"blockquote":"Cytat blokowy"}));
