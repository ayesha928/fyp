//>>built
define("dojox/editor/plugins/nls/it/InsertAnchor",({insertAnchor:"Inserisci ancoraggio",title:"Proprietà ancoraggio",anchor:"Nome:",text:"Descrizione:",set:"Imposta",cancel:"Annulla"}));
