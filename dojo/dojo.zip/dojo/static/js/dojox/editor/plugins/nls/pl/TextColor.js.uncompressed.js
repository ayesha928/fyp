define(
"dojox/editor/plugins/nls/pl/TextColor", ({
	"setButtonText": "Ustaw",
	"cancelButtonText": "Anuluj"
})
);
