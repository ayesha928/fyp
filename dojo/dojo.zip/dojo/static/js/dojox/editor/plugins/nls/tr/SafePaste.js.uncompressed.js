define(
"dojox/editor/plugins/nls/tr/SafePaste", ({
	"instructions": "Doğrudan kopyalama geçersiz kılındı. Lütfen bu iletişim kutusundaki içeriği standart tarayıcı klavyesini ya da menüde yer alan yapıştırma seçeneklerini kullanarak  yapıştırın. Eklenecek içeriğe karar verdikten sonra yapıştır düğmesine basın. İçeriği eklemeyi durdurmak için iptal düğmesine basın."
})
);
