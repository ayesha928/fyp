//>>built
define("dojox/editor/plugins/nls/pt/CollapsibleToolbar",({"collapse":"Reduzir Barra de Ferramentas do Editor","expand":"Expandir Barra de Ferramentas do Editor"}));
