define(
"dojox/editor/plugins/nls/da/PasteFromWord", ({
	"pasteFromWord": "Indsæt fra Word",
	"instructions": "Indsæt indholdet fra Word i tekstfeltet nedenfor. Klik på knappen Indsæt, når du er tilfreds med indholdet. Tryk på knappen Annullér for at fortryde indsættelsen."
})
);
