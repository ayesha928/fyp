//>>built
define("dojox/editor/plugins/nls/pt-pt/ShowBlockNodes",({"showBlockNodes":"Mostrar elementos do bloco HTML"}));
