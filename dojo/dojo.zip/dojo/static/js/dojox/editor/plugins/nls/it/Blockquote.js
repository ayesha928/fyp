//>>built
define("dojox/editor/plugins/nls/it/Blockquote",({"blockquote":"Blockquote"}));
