define(
"dojox/editor/plugins/nls/pt/Blockquote", ({
	"blockquote": "Citação de Bloco"
})
);
