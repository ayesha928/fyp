define(
"dojox/editor/plugins/nls/pl/PasteFromWord", ({
	"pasteFromWord": "Wklej z programu Word",
	"instructions": "Wklej tekst z programu Word do poniższego pola tekstowego. Po uzyskaniu odpowiedniej treści do wstawienia kliknij przycisk Wklej. Aby przerwać wstawianie treści, kliknij przycisk Anuluj."
})
);
