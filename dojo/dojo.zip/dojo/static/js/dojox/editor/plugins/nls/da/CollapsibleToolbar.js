//>>built
define("dojox/editor/plugins/nls/da/CollapsibleToolbar",({"collapse":"Skjul editorværktøjslinje","expand":"Udvid editorværktøjslinje"}));
