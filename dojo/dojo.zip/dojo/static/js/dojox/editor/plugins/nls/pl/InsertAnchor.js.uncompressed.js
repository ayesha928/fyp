define(
"dojox/editor/plugins/nls/pl/InsertAnchor", ({
	insertAnchor: "Wstaw zakotwiczenie",
	title: "Właściwości zakotwiczenia",
	anchor: "Nazwa:",
	text: "Opis:",
	set: "Ustaw",
	cancel: "Anuluj"
})
);
