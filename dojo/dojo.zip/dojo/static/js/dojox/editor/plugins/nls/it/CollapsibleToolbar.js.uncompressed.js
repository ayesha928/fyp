define(
"dojox/editor/plugins/nls/it/CollapsibleToolbar", ({
	"collapse": "Comprimi barra degli strumenti dell'editor",
	"expand": "Espandi barra degli strumenti dell'editor"
})
);
