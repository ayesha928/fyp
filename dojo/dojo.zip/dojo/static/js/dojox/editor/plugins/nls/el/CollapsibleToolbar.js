//>>built
define("dojox/editor/plugins/nls/el/CollapsibleToolbar",({"collapse":"Σύμπτυξη γραμμής εργαλείων λειτουργίας επεξεργασίας","expand":"Ανάπτυξη γραμμής εργαλείων λειτουργίας επεξεργασίας"}));
