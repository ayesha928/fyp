define(
"dojox/editor/plugins/nls/pt/LocalImage", ({
	insertImageTitle: "Inserir imagem",
	url: "Imagem",
	browse: "Procurar...",
	text: "Descrição",
	set: "Inserir",
	invalidMessage: "Tipo de arquivo de imagem inválido",
	prePopuTextUrl: "Insira uma URL de imagem",
	prePopuTextBrowse: " ou navegue até um arquivo local."
})
);
