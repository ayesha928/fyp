//>>built
define("dojox/editor/plugins/nls/pt/SafePaste",({"instructions":"A colagem direta está desativada. Cole o conteúdo neste diálogo usando o teclado de navegador padrão ou os controles de colagem do menu. Quando estiver satisfeito com o conteúdo a ser inserido, pressione o botão colar. Para interromper a inserção de conteúdo, pressione o botão cancelar."}));
