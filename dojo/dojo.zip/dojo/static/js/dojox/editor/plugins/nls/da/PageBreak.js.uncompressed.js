define(
"dojox/editor/plugins/nls/da/PageBreak", ({
	"pageBreak": "Sideskift"
})
);
