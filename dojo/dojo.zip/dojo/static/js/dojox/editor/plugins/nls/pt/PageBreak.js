//>>built
define("dojox/editor/plugins/nls/pt/PageBreak",({"pageBreak":"Quebra de Página"}));
