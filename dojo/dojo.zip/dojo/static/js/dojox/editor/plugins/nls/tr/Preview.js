//>>built
define("dojox/editor/plugins/nls/tr/Preview",({"preview":"Önizleme"}));
