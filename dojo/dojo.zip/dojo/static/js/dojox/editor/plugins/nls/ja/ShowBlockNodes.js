//>>built
define("dojox/editor/plugins/nls/ja/ShowBlockNodes",({"showBlockNodes":"HTML ブロック要素の表示"}));
