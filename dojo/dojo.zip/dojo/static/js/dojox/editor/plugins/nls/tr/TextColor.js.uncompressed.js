define(
"dojox/editor/plugins/nls/tr/TextColor", ({
	"setButtonText": "Ayarla",
	"cancelButtonText": "İptal"
})
);
