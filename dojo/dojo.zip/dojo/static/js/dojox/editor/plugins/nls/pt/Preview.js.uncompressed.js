define(
"dojox/editor/plugins/nls/pt/Preview", ({
	"preview": "Visualizar"
})
);
