//>>built
define("dojox/editor/plugins/nls/da/InsertAnchor",({insertAnchor:"Indsæt anker",title:"Egenskaber for anker",anchor:"Navn:",text:"Beskrivelse:",set:"Definér",cancel:"Annullér"}));
