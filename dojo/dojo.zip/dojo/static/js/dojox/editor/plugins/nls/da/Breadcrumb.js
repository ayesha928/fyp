//>>built
define("dojox/editor/plugins/nls/da/Breadcrumb",({"nodeActions":"Handlinger for ${nodeName}","selectContents":"Vælg indhold","selectElement":"Vælg element","deleteElement":"Slet element","deleteContents":"Slet indhold","moveStart":"Flyt markør til start","moveEnd":"Flyt markør til slut"}));
