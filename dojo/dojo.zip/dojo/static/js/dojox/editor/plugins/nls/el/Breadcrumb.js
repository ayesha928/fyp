//>>built
define("dojox/editor/plugins/nls/el/Breadcrumb",({"nodeActions":"${nodeName} - Ενέργειες","selectContents":"Επιλογή περιεχομένων","selectElement":"Επιλογή στοιχείου","deleteElement":"Διαγραφή στοιχείου","deleteContents":"Διαγραφή περιεχομένων","moveStart":"Μετακίνηση δρομέα στην αρχή","moveEnd":"Μετακίνηση δρομέα στο τέλος"}));
