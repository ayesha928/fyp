define(
"dojox/editor/plugins/nls/tr/PageBreak", ({
	"pageBreak": "Sayfa Sonu"
})
);
