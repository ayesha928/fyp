define(
"dojox/editor/plugins/nls/pl/LocalImage", ({
	insertImageTitle: "Wstaw obraz",
	url: "Obraz",
	browse: "Przeglądaj...",
	text: "Opis",
	set: "Wstaw",
	invalidMessage: "Niepoprawny typ pliku graficznego",
	prePopuTextUrl: "Wprowadź adres URL obrazu",
	prePopuTextBrowse: " lub wskaż plik lokalny. "
})
);
