define(
"dojox/editor/plugins/nls/ja/InsertEntity", ({
	insertEntity: "記号の挿入"
})
);
