define(
"dojox/editor/plugins/nls/pt/InsertEntity", ({
	insertEntity: "Inserir Símbolo"
})
);
