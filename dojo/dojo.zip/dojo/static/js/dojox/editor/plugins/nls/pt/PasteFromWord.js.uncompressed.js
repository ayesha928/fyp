define(
"dojox/editor/plugins/nls/pt/PasteFromWord", ({
	"pasteFromWord": "Colar do Word",
	"instructions": "Cole o conteúdo do Word na caixa de texto a seguir. Quando estiver satisfeito com o conteúdo a ser inserido, pressione o botão para colar. Para interromper a inserção de texto, pressione o botão para cancelar."
})
);
