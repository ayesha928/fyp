define(
"dojox/editor/plugins/nls/da/Blockquote", ({
	"blockquote": "Blokanførselstegn"
})
);
