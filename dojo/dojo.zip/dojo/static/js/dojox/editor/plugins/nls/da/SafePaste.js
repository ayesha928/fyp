//>>built
define("dojox/editor/plugins/nls/da/SafePaste",({"instructions":"Direkte indsættelse er deaktiveret. Indsæt indholdet i denne dialog ved hjælp af browserens standardtaster eller menupunkter til indsættelse. Klik på knappen Indsæt, når du er tilfreds med indholdet. Tryk på knappen Annullér for at fortryde indsættelsen."}));
