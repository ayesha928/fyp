define(
"dojox/editor/plugins/nls/pt-pt/Breadcrumb", ({
	"nodeActions": "Acções de ${nodeName}",
	"selectContents": "Seleccionar conteúdo",
	"selectElement": "Seleccionar elemento",
	"deleteElement": "Eliminar elemento",
	"deleteContents": "Eliminar conteúdo",
	"moveStart": "Mover cursor para o início",
	"moveEnd": "Mover cursor para o fim"
})
);
