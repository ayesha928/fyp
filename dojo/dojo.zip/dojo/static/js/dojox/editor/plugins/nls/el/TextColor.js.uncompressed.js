define(
"dojox/editor/plugins/nls/el/TextColor", ({
	"setButtonText": "Ορισμός",
	"cancelButtonText": "Ακύρωση"
})
);
