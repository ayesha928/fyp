//>>built
define("dojox/geo/openlayers/LineString",["dojo/_base/declare","./Geometry"],function(_1,_2){
return _1("dojox.geo.openlayers.LineString",_2,{setPoints:function(p){
this.coordinates=p;
},getPoints:function(){
return this.coordinates;
}});
});
