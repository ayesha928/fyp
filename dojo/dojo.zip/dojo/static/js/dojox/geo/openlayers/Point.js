//>>built
define("dojox/geo/openlayers/Point",["dojo/_base/declare","./Geometry"],function(_1,_2){
return _1("dojox.geo.openlayers.Point",_2,{setPoint:function(p){
this.coordinates=p;
},getPoint:function(){
return this.coordinates;
}});
});
