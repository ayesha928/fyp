//>>built
define("dojox/geo/openlayers/Geometry",["dojo/_base/declare"],function(_1){
return _1("dojox.geo.openlayers.Geometry",null,{coordinates:null,shape:null,constructor:function(_2){
this.coordinates=_2;
}});
});
