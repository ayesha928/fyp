//>>built
define("dojox/geo/openlayers/Collection",["dojo/_base/declare","./Geometry"],function(_1,_2){
return _1("dojox.geo.openlayers.Collection",_2,{coordinates:null,setGeometries:function(g){
this.coordinates=g;
},getGeometries:function(){
return this.coordinates;
}});
});
